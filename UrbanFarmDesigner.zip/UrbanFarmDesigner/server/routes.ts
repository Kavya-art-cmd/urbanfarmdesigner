import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertGardenSpaceSchema, 
  insertUserGardenSchema, 
  insertCareTaskSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefix
  const apiPrefix = "/api";
  
  // Get all garden designs
  app.get(`${apiPrefix}/garden-designs`, async (req, res) => {
    try {
      const designs = await storage.getGardenDesigns();
      res.json(designs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch garden designs", error: (error as Error).message });
    }
  });

  // Get garden design by ID
  app.get(`${apiPrefix}/garden-designs/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const design = await storage.getGardenDesign(id);
      
      if (!design) {
        return res.status(404).json({ message: "Garden design not found" });
      }
      
      res.json(design);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch garden design", error: (error as Error).message });
    }
  });

  // Get garden designs by type
  app.get(`${apiPrefix}/garden-designs/type/:type`, async (req, res) => {
    try {
      const { type } = req.params;
      const designs = await storage.getGardenDesignsByType(type);
      res.json(designs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch garden designs by type", error: (error as Error).message });
    }
  });

  // Get all plants
  app.get(`${apiPrefix}/plants`, async (req, res) => {
    try {
      const plants = await storage.getPlants();
      res.json(plants);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch plants", error: (error as Error).message });
    }
  });

  // Get plants by type
  app.get(`${apiPrefix}/plants/type/:type`, async (req, res) => {
    try {
      const { type } = req.params;
      const plants = await storage.getPlantsByType(type);
      res.json(plants);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch plants by type", error: (error as Error).message });
    }
  });

  // Get plants by sunlight requirements
  app.get(`${apiPrefix}/plants/sunlight/:sunlight`, async (req, res) => {
    try {
      const { sunlight } = req.params;
      const plants = await storage.getPlantsBySunlight(sunlight);
      res.json(plants);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch plants by sunlight", error: (error as Error).message });
    }
  });

  // Get plant by ID
  app.get(`${apiPrefix}/plants/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const plant = await storage.getPlant(id);
      
      if (!plant) {
        return res.status(404).json({ message: "Plant not found" });
      }
      
      res.json(plant);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch plant", error: (error as Error).message });
    }
  });

  // Create garden space
  app.post(`${apiPrefix}/garden-spaces`, async (req: Request, res: Response) => {
    try {
      const gardenSpaceData = insertGardenSpaceSchema.parse(req.body);
      const newGardenSpace = await storage.createGardenSpace(gardenSpaceData);
      res.status(201).json(newGardenSpace);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid garden space data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create garden space", error: (error as Error).message });
    }
  });

  // Generate recommended garden designs based on user inputs
  app.post(`${apiPrefix}/generate-designs`, async (req: Request, res: Response) => {
    try {
      const { spaceType, sunlightExposure, width, length, preferences } = req.body;
      
      // Validate required inputs
      if (!spaceType || !sunlightExposure || !width || !length) {
        return res.status(400).json({ message: "Missing required garden space details" });
      }
      
      // Get all designs
      const allDesigns = await storage.getGardenDesigns();
      
      // Filter designs based on sunlight compatibility
      let recommendedDesigns = allDesigns.filter(design => {
        if (sunlightExposure === "full" && design.sunlight.includes("full")) return true;
        if (sunlightExposure === "partial" && (design.sunlight.includes("partial") || design.sunlight === "full-partial")) return true;
        if (sunlightExposure === "shade" && design.sunlight !== "full") return true;
        return false;
      });
      
      // If we have more than 3 designs, prioritize based on space type
      if (recommendedDesigns.length > 3) {
        recommendedDesigns = recommendedDesigns.filter(design => {
          if (spaceType === "balcony" && (design.designType === "vertical" || design.designType === "container")) return true;
          if (spaceType === "terrace" && design.designType === "hybrid") return true;
          if (spaceType === "indoor" && design.designType === "container") return true;
          return false;
        });
      }
      
      // If still more than 3 or no designs found, take/limit to 3
      recommendedDesigns = recommendedDesigns.slice(0, 3);
      
      // If no designs match, return all designs limited to 3
      if (recommendedDesigns.length === 0) {
        recommendedDesigns = allDesigns.slice(0, 3);
      }
      
      res.json(recommendedDesigns);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate garden designs", error: (error as Error).message });
    }
  });

  // Get recommended plants based on design and space
  app.post(`${apiPrefix}/recommend-plants`, async (req: Request, res: Response) => {
    try {
      const { designId, sunlightExposure, preferences } = req.body;
      
      // Validate required inputs
      if (!sunlightExposure || !preferences || preferences.length === 0) {
        return res.status(400).json({ message: "Missing required plant recommendation parameters" });
      }
      
      // Get all plants
      const allPlants = await storage.getPlants();
      
      // Filter plants by user preferences
      let recommendedPlants = allPlants.filter(plant => 
        preferences.includes(plant.type)
      );
      
      // Further filter by sunlight compatibility
      recommendedPlants = recommendedPlants.filter(plant => {
        if (sunlightExposure === "full" && (plant.sunlight === "full" || plant.sunlight === "full-partial")) return true;
        if (sunlightExposure === "partial" && (plant.sunlight === "partial" || plant.sunlight === "full-partial")) return true;
        if (sunlightExposure === "shade" && plant.sunlight !== "full") return true;
        return false;
      });
      
      // Group plants by type
      const plantsByType: Record<string, any[]> = {};
      recommendedPlants.forEach(plant => {
        if (!plantsByType[plant.type]) {
          plantsByType[plant.type] = [];
        }
        plantsByType[plant.type].push(plant);
      });
      
      res.json(plantsByType);
    } catch (error) {
      res.status(500).json({ message: "Failed to recommend plants", error: (error as Error).message });
    }
  });

  // Create a user garden (save a design)
  app.post(`${apiPrefix}/user-gardens`, async (req: Request, res: Response) => {
    try {
      const userGardenData = insertUserGardenSchema.parse(req.body);
      const newUserGarden = await storage.createUserGarden(userGardenData);
      res.status(201).json(newUserGarden);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user garden data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user garden", error: (error as Error).message });
    }
  });

  // Update user garden progress
  app.patch(`${apiPrefix}/user-gardens/:id/progress`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { progress } = req.body;
      
      if (typeof progress !== 'number' || progress < 0 || progress > 100) {
        return res.status(400).json({ message: "Progress must be a number between 0 and 100" });
      }
      
      const updatedGarden = await storage.updateUserGardenProgress(id, progress);
      res.json(updatedGarden);
    } catch (error) {
      res.status(500).json({ message: "Failed to update progress", error: (error as Error).message });
    }
  });

  // Create a care task
  app.post(`${apiPrefix}/care-tasks`, async (req: Request, res: Response) => {
    try {
      const careTaskData = insertCareTaskSchema.parse(req.body);
      const newCareTask = await storage.createCareTask(careTaskData);
      res.status(201).json(newCareTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid care task data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create care task", error: (error as Error).message });
    }
  });

  // Update care task completion status
  app.patch(`${apiPrefix}/care-tasks/:id/complete`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { completed } = req.body;
      
      if (typeof completed !== 'boolean') {
        return res.status(400).json({ message: "Completed status must be a boolean" });
      }
      
      const updatedTask = await storage.updateCareTaskCompletion(id, completed);
      res.json(updatedTask);
    } catch (error) {
      res.status(500).json({ message: "Failed to update task completion", error: (error as Error).message });
    }
  });

  // Get care tasks for a user garden
  app.get(`${apiPrefix}/user-gardens/:id/care-tasks`, async (req: Request, res: Response) => {
    try {
      const userGardenId = parseInt(req.params.id);
      const tasks = await storage.getCareTasks(userGardenId);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch care tasks", error: (error as Error).message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
