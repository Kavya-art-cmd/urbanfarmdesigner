import { 
  users, type User, type InsertUser,
  gardenSpaces, type GardenSpace, type InsertGardenSpace,
  gardenDesigns, type GardenDesign, type InsertGardenDesign,
  plants, type Plant, type InsertPlant,
  userGardens, type UserGarden, type InsertUserGarden,
  careTasks, type CareTask, type InsertCareTask 
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Garden space operations
  getGardenSpaces(): Promise<GardenSpace[]>;
  getGardenSpace(id: number): Promise<GardenSpace | undefined>;
  createGardenSpace(space: InsertGardenSpace): Promise<GardenSpace>;

  // Garden design operations
  getGardenDesigns(): Promise<GardenDesign[]>;
  getGardenDesignsByType(type: string): Promise<GardenDesign[]>;
  getGardenDesignsBySunlight(sunlight: string): Promise<GardenDesign[]>;
  getGardenDesign(id: number): Promise<GardenDesign | undefined>;
  createGardenDesign(design: InsertGardenDesign): Promise<GardenDesign>;

  // Plant operations
  getPlants(): Promise<Plant[]>;
  getPlantsByType(type: string): Promise<Plant[]>;
  getPlantsBySunlight(sunlight: string): Promise<Plant[]>;
  getPlant(id: number): Promise<Plant | undefined>;
  createPlant(plant: InsertPlant): Promise<Plant>;

  // User garden operations
  getUserGardens(userId: number): Promise<UserGarden[]>;
  getUserGarden(id: number): Promise<UserGarden | undefined>;
  createUserGarden(garden: InsertUserGarden): Promise<UserGarden>;
  updateUserGardenProgress(id: number, progress: number): Promise<UserGarden>;

  // Care task operations
  getCareTasks(userGardenId: number): Promise<CareTask[]>;
  getCareTask(id: number): Promise<CareTask | undefined>;
  createCareTask(task: InsertCareTask): Promise<CareTask>;
  updateCareTaskCompletion(id: number, completed: boolean): Promise<CareTask>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private gardenSpaces: Map<number, GardenSpace>;
  private gardenDesigns: Map<number, GardenDesign>;
  private plants: Map<number, Plant>;
  private userGardens: Map<number, UserGarden>;
  private careTasks: Map<number, CareTask>;
  
  private currentUserId: number;
  private currentGardenSpaceId: number;
  private currentGardenDesignId: number;
  private currentPlantId: number;
  private currentUserGardenId: number;
  private currentCareTaskId: number;

  constructor() {
    this.users = new Map();
    this.gardenSpaces = new Map();
    this.gardenDesigns = new Map();
    this.plants = new Map();
    this.userGardens = new Map();
    this.careTasks = new Map();
    
    this.currentUserId = 1;
    this.currentGardenSpaceId = 1;
    this.currentGardenDesignId = 1;
    this.currentPlantId = 1;
    this.currentUserGardenId = 1;
    this.currentCareTaskId = 1;
    
    // Initialize with sample data
    this.initializeGardenDesigns();
    this.initializePlants();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Garden space operations
  async getGardenSpaces(): Promise<GardenSpace[]> {
    return Array.from(this.gardenSpaces.values());
  }

  async getGardenSpace(id: number): Promise<GardenSpace | undefined> {
    return this.gardenSpaces.get(id);
  }

  async createGardenSpace(insertSpace: InsertGardenSpace): Promise<GardenSpace> {
    const id = this.currentGardenSpaceId++;
    const now = new Date();
    const space: GardenSpace = { 
      ...insertSpace, 
      id, 
      createdAt: now 
    };
    this.gardenSpaces.set(id, space);
    return space;
  }

  // Garden design operations
  async getGardenDesigns(): Promise<GardenDesign[]> {
    return Array.from(this.gardenDesigns.values());
  }

  async getGardenDesignsByType(type: string): Promise<GardenDesign[]> {
    return Array.from(this.gardenDesigns.values()).filter(
      (design) => design.designType === type
    );
  }

  async getGardenDesignsBySunlight(sunlight: string): Promise<GardenDesign[]> {
    return Array.from(this.gardenDesigns.values()).filter(
      (design) => design.sunlight === sunlight
    );
  }

  async getGardenDesign(id: number): Promise<GardenDesign | undefined> {
    return this.gardenDesigns.get(id);
  }

  async createGardenDesign(insertDesign: InsertGardenDesign): Promise<GardenDesign> {
    const id = this.currentGardenDesignId++;
    const design: GardenDesign = { ...insertDesign, id };
    this.gardenDesigns.set(id, design);
    return design;
  }

  // Plant operations
  async getPlants(): Promise<Plant[]> {
    return Array.from(this.plants.values());
  }

  async getPlantsByType(type: string): Promise<Plant[]> {
    return Array.from(this.plants.values()).filter(
      (plant) => plant.type === type
    );
  }

  async getPlantsBySunlight(sunlight: string): Promise<Plant[]> {
    return Array.from(this.plants.values()).filter(
      (plant) => plant.sunlight === sunlight
    );
  }

  async getPlant(id: number): Promise<Plant | undefined> {
    return this.plants.get(id);
  }

  async createPlant(insertPlant: InsertPlant): Promise<Plant> {
    const id = this.currentPlantId++;
    const plant: Plant = { ...insertPlant, id };
    this.plants.set(id, plant);
    return plant;
  }

  // User garden operations
  async getUserGardens(userId: number): Promise<UserGarden[]> {
    return Array.from(this.userGardens.values()).filter(
      (garden) => garden.userId === userId
    );
  }

  async getUserGarden(id: number): Promise<UserGarden | undefined> {
    return this.userGardens.get(id);
  }

  async createUserGarden(insertGarden: InsertUserGarden): Promise<UserGarden> {
    const id = this.currentUserGardenId++;
    const now = new Date();
    const garden: UserGarden = { 
      ...insertGarden, 
      id, 
      createdAt: now 
    };
    this.userGardens.set(id, garden);
    return garden;
  }

  async updateUserGardenProgress(id: number, progress: number): Promise<UserGarden> {
    const garden = this.userGardens.get(id);
    if (!garden) {
      throw new Error(`Garden with id ${id} not found`);
    }
    const updated = { ...garden, progress };
    this.userGardens.set(id, updated);
    return updated;
  }

  // Care task operations
  async getCareTasks(userGardenId: number): Promise<CareTask[]> {
    return Array.from(this.careTasks.values()).filter(
      (task) => task.userGardenId === userGardenId
    );
  }

  async getCareTask(id: number): Promise<CareTask | undefined> {
    return this.careTasks.get(id);
  }

  async createCareTask(insertTask: InsertCareTask): Promise<CareTask> {
    const id = this.currentCareTaskId++;
    const now = new Date();
    const task: CareTask = { 
      ...insertTask, 
      id, 
      createdAt: now 
    };
    this.careTasks.set(id, task);
    return task;
  }

  async updateCareTaskCompletion(id: number, completed: boolean): Promise<CareTask> {
    const task = this.careTasks.get(id);
    if (!task) {
      throw new Error(`Task with id ${id} not found`);
    }
    const updated = { ...task, completed };
    this.careTasks.set(id, updated);
    return updated;
  }

  // Initialize sample data
  private initializeGardenDesigns() {
    const designs: InsertGardenDesign[] = [
      {
        name: "Vertical Herb Haven",
        description: "Perfect for limited space with maximum vertical growth. Ideal for herbs and small vegetables.",
        designType: "vertical",
        imageUrl: "/src/assets/garden-vertical.svg",
        sunlight: "full",
        waterNeeds: "low",
        careLevel: "easy",
        spaceEfficiency: 85,
        materialsList: [
          "Vertical garden wall planter",
          "Potting soil (15-20L)",
          "Basic gardening tools",
          "Small containers for propagation"
        ]
      },
      {
        name: "Modular Veggie Garden",
        description: "Flexible container arrangement for vegetables with rotating seasonal options.",
        designType: "container",
        imageUrl: "https://images.unsplash.com/photo-1581578017066-9e511e578182?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "partial",
        waterNeeds: "medium",
        careLevel: "moderate",
        spaceEfficiency: 75,
        materialsList: [
          "5-7 medium containers (10-12 inch diameter)",
          "Potting soil mix (30-40L)",
          "Basic gardening tools",
          "Trellis for climbing plants"
        ]
      },
      {
        name: "Balcony Food Forest",
        description: "Mix of hanging, vertical and container elements for maximum variety and yield.",
        designType: "hybrid",
        imageUrl: "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "full-partial",
        waterNeeds: "medium",
        careLevel: "advanced",
        spaceEfficiency: 90,
        materialsList: [
          "Vertical planters",
          "Hanging baskets",
          "Medium to large containers",
          "Potting soil mix (40-50L)",
          "Trellis system",
          "Gardening toolkit"
        ]
      }
    ];

    designs.forEach(design => {
      this.createGardenDesign(design);
    });
  }

  private initializePlants() {
    // Herbs
    const herbs: InsertPlant[] = [
      {
        name: "Basil",
        type: "herb",
        description: "Aromatic herb, perfect for cooking",
        imageUrl: "https://images.unsplash.com/photo-1599547825517-fe142432bf47?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "full",
        waterNeeds: "regular",
        careLevel: "beginner",
        specialFeature: "Easy to Grow",
        harvestTime: "30-60 days"
      },
      {
        name: "Mint",
        type: "herb",
        description: "Refreshing herb for drinks and dishes",
        imageUrl: "https://images.unsplash.com/photo-1582556135623-653e9740c8ea?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "partial",
        waterNeeds: "regular",
        careLevel: "beginner",
        specialFeature: "Fast Growing",
        harvestTime: "30 days"
      },
      {
        name: "Rosemary",
        type: "herb",
        description: "Fragrant herb for savory dishes",
        imageUrl: "https://images.unsplash.com/photo-1609252507620-a2121878d8d4?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "full",
        waterNeeds: "low",
        careLevel: "beginner",
        specialFeature: "Drought Tolerant",
        harvestTime: "90 days"
      },
      {
        name: "Cilantro",
        type: "herb",
        description: "Perfect for salsa and Asian cuisine",
        imageUrl: "https://images.unsplash.com/photo-1603904068109-38e127dc0156?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "partial",
        waterNeeds: "regular",
        careLevel: "beginner",
        specialFeature: "Quick Harvest",
        harvestTime: "21-28 days"
      }
    ];

    // Vegetables
    const vegetables: InsertPlant[] = [
      {
        name: "Cherry Tomatoes",
        type: "vegetable",
        description: "Sweet and productive in small spaces",
        imageUrl: "https://images.unsplash.com/photo-1592919505780-303950717480?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "full",
        waterNeeds: "regular",
        careLevel: "beginner-friendly",
        specialFeature: "High Yield",
        harvestTime: "60-80 days"
      },
      {
        name: "Bell Peppers",
        type: "vegetable",
        description: "Colorful and nutritious container crop",
        imageUrl: "https://images.unsplash.com/photo-1584636379677-254ce5755cfe?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "full",
        waterNeeds: "regular",
        careLevel: "intermediate",
        specialFeature: "Compact Variety",
        harvestTime: "60-90 days"
      },
      {
        name: "Lettuce",
        type: "vegetable",
        description: "Leafy greens for continuous harvest",
        imageUrl: "https://images.unsplash.com/photo-1604324704024-1e0c20e05859?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "partial",
        waterNeeds: "regular",
        careLevel: "beginner",
        specialFeature: "Fast Growing",
        harvestTime: "30-45 days"
      },
      {
        name: "Radishes",
        type: "vegetable",
        description: "Ready to harvest in just 3-4 weeks",
        imageUrl: "https://images.unsplash.com/photo-1576300295001-e889d7ec1ef6?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
        sunlight: "full-partial",
        waterNeeds: "regular",
        careLevel: "beginner",
        specialFeature: "Quick Harvest",
        harvestTime: "21-30 days"
      }
    ];

    // Add more plant types as needed
    [...herbs, ...vegetables].forEach(plant => {
      this.createPlant(plant);
    });
  }
}

export const storage = new MemStorage();
