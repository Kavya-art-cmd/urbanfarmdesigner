// Type definitions for client-side use

export interface GardenDesign {
  id: number;
  name: string;
  description: string;
  designType: string;
  imageUrl: string;
  sunlight: string;
  waterNeeds: string;
  careLevel: string;
  spaceEfficiency: number;
  materialsList: string[] | any;
}

export interface Plant {
  id: number;
  name: string;
  type: string;
  description: string;
  imageUrl: string;
  sunlight: string;
  waterNeeds: string;
  careLevel: string;
  specialFeature?: string;
  harvestTime?: string;
}

export interface GardenSpace {
  id: number;
  userId?: number;
  name: string;
  spaceType: string;
  width: number;
  length: number;
  sunlightExposure: string;
  preferences: string[];
  photoUrl?: string;
  createdAt: Date;
}

export interface UserGarden {
  id: number;
  userId: number;
  gardenSpaceId: number;
  designId: number;
  selectedPlants: number[];
  progress: number;
  createdAt: Date;
}

export interface CareTask {
  id: number;
  userGardenId: number;
  title: string;
  description: string;
  taskType: string;
  dueDate: Date;
  completed: boolean;
  createdAt: Date;
}
