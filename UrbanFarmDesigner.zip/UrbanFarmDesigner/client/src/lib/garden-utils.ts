/**
 * Utility functions for the garden application
 */

// Design type helpers
export const designTypeLabels: Record<string, string> = {
  "vertical": "Vertical Garden",
  "container": "Container Garden",
  "hybrid": "Hybrid Garden"
};

export const designTypeColors: Record<string, string> = {
  "vertical": "bg-primary",
  "container": "bg-accent",
  "hybrid": "bg-[#8BC34A]" // primary-light color
};

// Sunlight exposure helpers
export const sunlightLabels: Record<string, string> = {
  "full": "Full Sun",
  "partial": "Partial Sun",
  "shade": "Shade",
  "full-partial": "Full-Partial Sun"
};

export const sunlightDescriptions: Record<string, string> = {
  "full": "6+ hours of direct sunlight daily",
  "partial": "3-6 hours of direct sunlight daily",
  "shade": "Less than 3 hours of direct sunlight daily",
  "full-partial": "Variable sunlight conditions"
};

// Water needs helpers
export const waterNeedsLabels: Record<string, string> = {
  "low": "Low Water",
  "medium": "Medium Water",
  "high": "High Water",
  "regular": "Regular Water"
};

export const waterNeedsDescriptions: Record<string, string> = {
  "low": "Water once every 1-2 weeks",
  "medium": "Water once every week",
  "high": "Water multiple times per week",
  "regular": "Water 2-3 times per week"
};

// Care level helpers
export const careLevelLabels: Record<string, string> = {
  "easy": "Easy Care",
  "moderate": "Moderate Care",
  "advanced": "Advanced Care",
  "beginner": "Beginner-Friendly",
  "intermediate": "Intermediate",
  "beginner-friendly": "Beginner-Friendly"
};

export const careLevelDescriptions: Record<string, string> = {
  "easy": "Perfect for beginners, requires minimal maintenance",
  "moderate": "Needs regular attention but forgiving of mistakes",
  "advanced": "Requires consistent care and gardening knowledge",
  "beginner": "Perfect for beginners, requires minimal maintenance",
  "intermediate": "Needs regular attention but forgiving of mistakes",
  "beginner-friendly": "Perfect for beginners, requires minimal maintenance"
};

// Plant type helpers
export const plantTypeLabels: Record<string, string> = {
  "herb": "Herbs",
  "vegetable": "Vegetables",
  "flower": "Flowers",
  "fruit": "Fruits"
};

export const plantTypeDescriptions: Record<string, string> = {
  "herb": "Perfect for vertical gardens",
  "vegetable": "Ideal for container gardening",
  "flower": "Add color and attract pollinators",
  "fruit": "Delicious edibles for your garden"
};

// Task type helpers
export const taskTypeLabels: Record<string, string> = {
  "water": "Water",
  "fertilize": "Fertilize",
  "prune": "Prune",
  "harvest": "Harvest"
};

export const taskTypeColors: Record<string, string> = {
  "water": "bg-blue-100 text-blue-800",
  "fertilize": "bg-green-100 text-green-800",
  "prune": "bg-purple-100 text-purple-800",
  "harvest": "bg-yellow-100 text-yellow-800"
};

export const taskTypeIconColors: Record<string, string> = {
  "water": "bg-blue-500",
  "fertilize": "bg-green-500",
  "prune": "bg-purple-500",
  "harvest": "bg-primary"
};

// Space calculation helpers
export interface SpaceDimensions {
  width: number;
  length: number;
}

export function calculateArea(dimensions: SpaceDimensions): number {
  return dimensions.width * dimensions.length;
}

export function calculatePlantCapacity(
  area: number, 
  plantType: string
): number {
  // Approximate plants per square foot
  const plantsPerSqFoot: Record<string, number> = {
    "herb": 4,
    "vegetable": 1,
    "flower": 2,
    "fruit": 0.5
  };
  
  return Math.floor(area * (plantsPerSqFoot[plantType] || 1));
}

// Date formatting helpers
export function formatDate(date: Date): string {
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });
}

// Design recommendation helpers
export function isDesignSuitableForSpace(
  designType: string,
  spaceType: string,
  dimensions: SpaceDimensions
): boolean {
  const area = calculateArea(dimensions);
  
  switch (spaceType) {
    case "balcony":
      // Balconies are best for vertical and smaller container setups
      if (area < 20) {
        return designType === "vertical";
      } else if (area < 40) {
        return designType === "vertical" || designType === "container";
      }
      return true;
      
    case "terrace":
      // Terraces can accommodate most designs, but very small ones may be limited
      if (area < 30) {
        return designType === "vertical" || designType === "container";
      }
      return true;
      
    case "indoor":
      // Indoor spaces are generally best for container gardens
      return designType === "container" || (designType === "vertical" && area > 15);
      
    default:
      return true;
  }
}

// Plant recommendation helpers
export function isPlantSuitableForConditions(
  sunlightNeeded: string,
  availableSunlight: string
): boolean {
  if (sunlightNeeded === availableSunlight) return true;
  
  if (availableSunlight === "full") {
    return true; // Full sun can accommodate all plants
  }
  
  if (availableSunlight === "partial") {
    return sunlightNeeded === "partial" || sunlightNeeded === "shade" || sunlightNeeded === "full-partial";
  }
  
  if (availableSunlight === "shade") {
    return sunlightNeeded === "shade";
  }
  
  if (availableSunlight === "full-partial") {
    return sunlightNeeded !== "shade";
  }
  
  return false;
}

// Progress tracking helpers
export function calculateSetupProgress(completedSteps: number, totalSteps: number): number {
  return Math.round((completedSteps / totalSteps) * 100);
}

// Generate demo data for calendar (for display only)
export function generateCalendarTasksForMonth(
  year: number,
  month: number
): Record<number, string[]> {
  const tasks: Record<number, string[]> = {};
  
  // Get the number of days in the month
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  
  for (let day = 1; day <= daysInMonth; day++) {
    tasks[day] = [];
    
    // Add watering tasks every 3 days
    if (day % 3 === 1) {
      tasks[day].push("water");
    }
    
    // Add fertilizing tasks every 10 days
    if (day % 10 === 0) {
      tasks[day].push("fertilize");
    }
    
    // Add pruning tasks every 7 days
    if (day % 7 === 0) {
      tasks[day].push("prune");
    }
    
    // Add a harvesting task in the middle of the month
    if (day === 14) {
      tasks[day].push("harvest");
    }
  }
  
  return tasks;
}
