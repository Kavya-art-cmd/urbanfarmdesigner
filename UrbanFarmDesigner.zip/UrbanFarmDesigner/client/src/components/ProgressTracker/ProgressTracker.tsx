import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { 
  CheckCircle,
  Circle, 
  Star
} from "lucide-react";

const ProgressTracker = () => {
  // In a real application, this data would come from an API
  const setupProgress = 80;
  const setupTasks = [
    { task: "Select garden design", completed: true },
    { task: "Purchase containers", completed: true },
    { task: "Get potting soil", completed: true },
    { task: "Select plant varieties", completed: true },
    { task: "Set up irrigation system", completed: false },
  ];

  const plantHealth = 92;
  const plantRatings = [
    { type: "Herbs", rating: 5 },
    { type: "Vegetables", rating: 4 },
    { type: "Microgreens", rating: 5 },
  ];

  const harvestData = [
    { name: "Basil", amount: 450, percentage: 75 },
    { name: "Cherry Tomatoes", amount: 300, percentage: 45 },
    { name: "Lettuce", amount: 600, percentage: 90 },
  ];

  return (
    <section className="py-12 bg-neutral-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-neutral-800 mb-4">Track Your Progress</h2>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Monitor your garden's growth and stay motivated as you build your urban oasis.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {/* Garden Setup Card */}
          <Card className="bg-white rounded-xl shadow-sm">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-lg">Garden Setup</h3>
                <span className="text-sm font-medium text-primary">{setupProgress}% Complete</span>
              </div>
              <Progress value={setupProgress} className="h-2.5 mb-6" />
              <div className="space-y-3">
                {setupTasks.map((task, index) => (
                  <div key={index} className="flex items-center">
                    <div className={`w-5 h-5 ${task.completed ? 'bg-primary' : 'border-2 border-neutral-300'} rounded-full flex items-center justify-center mr-3`}>
                      {task.completed && <CheckCircle className="text-white h-3 w-3" />}
                    </div>
                    <span className={`${task.completed ? 'text-neutral-600' : 'text-neutral-500'}`}>
                      {task.task}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Plant Health Card */}
          <Card className="bg-white rounded-xl shadow-sm">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-lg">Plant Health</h3>
                <div className="flex items-center">
                  <span className="text-sm font-medium text-green-600">Excellent</span>
                </div>
              </div>
              <div className="flex items-center justify-center my-3">
                <div className="relative w-32 h-32">
                  <svg className="w-full h-full" viewBox="0 0 36 36">
                    <path
                      className="progress-circle"
                      strokeDasharray={`${plantHealth}, 100`}
                      strokeDashoffset="0"
                      fill="none"
                      stroke="#4CAF50"
                      strokeWidth="3"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                    <text x="18" y="20.35" className="text-lg font-bold" textAnchor="middle" fill="#4CAF50">
                      {plantHealth}%
                    </text>
                  </svg>
                </div>
              </div>
              <div className="space-y-2">
                {plantRatings.map((item, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-neutral-600 text-sm">{item.type}</span>
                    <div className="flex">
                      {Array(5).fill(0).map((_, i) => (
                        <Star 
                          key={i}
                          className={`${i < item.rating ? 'text-yellow-500 fill-yellow-500' : 'text-yellow-500'} h-4 w-4`} 
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Harvest Tracker Card */}
          <Card className="bg-white rounded-xl shadow-sm">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-lg">Harvest Tracker</h3>
                <span className="text-sm font-medium text-primary">
                  {new Date().toLocaleString('default', { month: 'long' })}
                </span>
              </div>
              <div className="space-y-4 mb-6">
                {harvestData.map((item, index) => (
                  <div key={index}>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-neutral-600 text-sm">{item.name}</span>
                      <span className="text-neutral-800 text-sm font-medium">{item.amount}g</span>
                    </div>
                    <Progress 
                      value={item.percentage} 
                      className={`h-2 ${getProgressColor(index)}`} 
                    />
                  </div>
                ))}
              </div>
              <div className="text-center">
                <button className="text-primary hover:text-[#388E3C] font-medium text-sm">
                  View Complete Harvest History
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

// Helper function to vary progress bar colors
function getProgressColor(index: number): string {
  const colors = [
    "bg-[#8BC34A]", // primary-light
    "bg-accent",    // accent
    "bg-green-600", // different green
  ];
  return colors[index % colors.length];
}

export default ProgressTracker;
