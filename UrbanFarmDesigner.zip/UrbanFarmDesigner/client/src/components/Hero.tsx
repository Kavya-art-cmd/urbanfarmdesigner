import { Button } from "@/components/ui/button";

const Hero = () => {
  const scrollToDesignForm = () => {
    const designForm = document.getElementById("design-form");
    if (designForm) {
      designForm.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="bg-gradient-to-br from-[#8BC34A] to-[#4CAF50] py-12 sm:py-16 lg:py-20 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
              Grow Your Own <span className="text-neutral-100">Urban Garden</span>
            </h2>
            <p className="text-lg opacity-90 mb-8">
              Transform your balcony or terrace into a thriving green space. Design your home farm easily with personalized recommendations.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button 
                className="bg-white text-primary hover:bg-neutral-100 font-bold py-3 px-6 rounded-lg h-auto"
                onClick={scrollToDesignForm}
              >
                Design My Garden
              </Button>
              <Button 
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-primary font-bold py-3 px-6 rounded-lg h-auto"
              >
                Learn More
              </Button>
            </div>
          </div>
          <div className="flex justify-center">
            <img 
              src="https://images.unsplash.com/photo-1595915636673-b9475fa8f007?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
              alt="Urban balcony garden" 
              className="rounded-lg shadow-xl max-w-full h-auto"
              width="500" 
              height="375"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
