import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Instagram, 
  Facebook, 
  Youtube, 
  Send
} from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-neutral-800 text-white py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <svg className="text-primary h-5 w-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L11.2 3.5C11 3.8 10.8 4.1 10.7 4.4L9.8 7.1C9.4 8.3 9.8 9.6 10.8 10.3L11.4 10.7C11.8 11 12 11.4 12 11.9V13.5C12 14.1 11.8 14.7 11.4 15.2L11 15.8C10.6 16.3 10.4 16.9 10.4 17.5V22M12 2C12 2 14 6 14 7.5C14 8.9 13.3 10 12 10C10.7 10 10 8.9 10 7.5C10 6 12 2 12 2ZM20 19C20 21.2 16.4 23 12 23C7.6 23 4 21.2 4 19C4 17.8 4 17 7 17L15.6 17C19.1 17 20 17.3 20 19Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <h3 className="text-lg font-bold">Home Farm Designer</h3>
            </div>
            <p className="text-neutral-400 mb-4">
              Helping urbanites create thriving gardens in small spaces.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Resources</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Gardening Guides</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Plant Encyclopedia</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Seasonal Tips</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Video Tutorials</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Company</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Blog</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Partnerships</a></li>
              <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Contact Us</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Stay Updated</h4>
            <p className="text-neutral-400 mb-4">Subscribe to get gardening tips and updates.</p>
            <div className="flex">
              <Input 
                type="email" 
                placeholder="Your email" 
                className="bg-neutral-700 border-neutral-700 text-white rounded-r-none focus:ring-primary"
              />
              <Button className="bg-primary hover:bg-[#388E3C] rounded-l-none">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-neutral-700 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-neutral-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Home Farm Designer. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a href="#" className="text-neutral-400 hover:text-white text-sm transition-colors">Privacy Policy</a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm transition-colors">Terms of Service</a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
