import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  ChevronLeft, 
  ChevronRight,
  Leaf,
  Droplets,
  Sprout
} from "lucide-react";

// Sample calendar data - normally this would come from an API
const DAYS_OF_WEEK = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

type Task = {
  id: number;
  title: string;
  description: string;
  date: Date;
  type: "water" | "harvest" | "fertilize" | "prune";
};

interface CalendarDay {
  day: number;
  isCurrentMonth: boolean;
  tasks: string[];
  isToday?: boolean;
}

interface CareCalendarProps {
  gardenId?: number;
}

const CareCalendar = ({ gardenId }: CareCalendarProps) => {
  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());

  // Navigate to the previous month
  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  // Navigate to the next month
  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  // Generate calendar days
  const generateCalendarDays = (): CalendarDay[] => {
    const days: CalendarDay[] = [];
    
    // First day of the current month
    const firstDay = new Date(currentYear, currentMonth, 1);
    const startingDayOfWeek = firstDay.getDay();
    
    // Last day of the current month
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const totalDays = lastDay.getDate();
    
    // Previous month days to display
    const prevMonthLastDay = new Date(currentYear, currentMonth, 0).getDate();
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      days.push({
        day: prevMonthLastDay - i,
        isCurrentMonth: false,
        tasks: []
      });
    }
    
    // Current month days
    for (let i = 1; i <= totalDays; i++) {
      const isToday = today.getDate() === i && 
                     today.getMonth() === currentMonth && 
                     today.getFullYear() === currentYear;
      
      // Add some sample tasks - in a real app, these would come from an API
      const tasks = [];
      if (i % 3 === 1) tasks.push("water");
      if (i % 10 === 0) tasks.push("fertilize");
      if (i % 7 === 0) tasks.push("prune");
      if (i === 14) tasks.push("harvest");
      
      days.push({
        day: i,
        isCurrentMonth: true,
        tasks,
        isToday
      });
    }
    
    // Next month days to complete the grid (to make it 6 rows)
    const remainingDays = 42 - days.length;
    for (let i = 1; i <= remainingDays; i++) {
      days.push({
        day: i,
        isCurrentMonth: false,
        tasks: []
      });
    }
    
    return days;
  };

  const calendarDays = generateCalendarDays();

  // Sample upcoming tasks
  const upcomingTasks: Task[] = [
    {
      id: 1,
      title: "Harvest Basil and Mint",
      description: "Trim top leaves for continued growth and best flavor",
      date: new Date(currentYear, currentMonth, 14),
      type: "harvest"
    },
    {
      id: 2,
      title: "Water All Plants",
      description: "Water thoroughly early in the morning for best results",
      date: new Date(currentYear, currentMonth, 16),
      type: "water"
    },
    {
      id: 3,
      title: "Fertilize Vegetables",
      description: "Apply organic fertilizer to tomatoes and peppers",
      date: new Date(currentYear, currentMonth, 17),
      type: "fertilize"
    }
  ];

  const getTaskIconColor = (taskType: string): string => {
    switch (taskType) {
      case "water": return "bg-blue-100 text-blue-800";
      case "fertilize": return "bg-green-100 text-green-800";
      case "prune": return "bg-purple-100 text-purple-800";
      case "harvest": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTaskIcon = (type: string) => {
    switch (type) {
      case "water": return <Droplets className="h-4 w-4 text-blue-500" />;
      case "harvest": return <Leaf className="h-4 w-4 text-primary" />;
      case "fertilize": return <Sprout className="h-4 w-4 text-green-500" />;
      default: return null;
    }
  };

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-neutral-800 mb-4">Your Garden Care Calendar</h2>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Keep track of important dates and tasks to keep your urban garden thriving.
          </p>
        </div>

        <Card className="bg-neutral-100 rounded-2xl">
          <CardContent className="p-6 max-w-4xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={prevMonth}
                className="text-neutral-700 hover:text-primary"
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
              <h3 className="text-xl font-semibold text-neutral-800">
                {MONTHS[currentMonth]} {currentYear}
              </h3>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={nextMonth}
                className="text-neutral-700 hover:text-primary"
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            </div>

            <div className="grid grid-cols-7 gap-2 text-center mb-4">
              {DAYS_OF_WEEK.map(day => (
                <div key={day} className="text-sm font-medium text-neutral-500">{day}</div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-2">
              {calendarDays.map((day, index) => (
                <div 
                  key={index} 
                  className={`
                    rounded-lg p-2 h-24 border text-sm
                    ${day.isCurrentMonth 
                      ? (day.isToday 
                          ? 'bg-primary-light bg-opacity-20 border-primary-light' 
                          : 'bg-white border-neutral-200') 
                      : 'bg-neutral-50 border-neutral-100 text-neutral-400'}
                  `}
                >
                  <div className={`text-sm ${day.isToday ? 'font-bold' : 'font-medium'} mb-1`}>
                    {day.day}
                  </div>
                  {day.tasks.map((task, i) => (
                    <div 
                      key={i} 
                      className={`${getTaskIconColor(task)} text-xs px-1 py-0.5 rounded mb-1`}
                    >
                      {task.charAt(0).toUpperCase() + task.slice(1)}
                    </div>
                  ))}
                  {day.isToday && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-primary rounded-full"></div>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-6">
              <h4 className="font-semibold mb-3">Upcoming Tasks</h4>
              <div className="space-y-3">
                {upcomingTasks.map(task => (
                  <div key={task.id} className="flex items-start bg-white p-3 rounded-lg border border-neutral-200">
                    <div className={`rounded-full w-8 h-8 flex items-center justify-center text-white mr-3 flex-shrink-0 ${getTaskIconBg(task.type)}`}>
                      {getTaskIcon(task.type)}
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <h5 className="font-medium text-neutral-800">{task.title}</h5>
                        <span className="text-xs text-neutral-500">
                          {task.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </span>
                      </div>
                      <p className="text-sm text-neutral-600">{task.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

// Helper function for task icon background colors
const getTaskIconBg = (type: string): string => {
  switch (type) {
    case "water": return "bg-blue-500";
    case "harvest": return "bg-primary";
    case "fertilize": return "bg-green-500";
    case "prune": return "bg-purple-500";
    default: return "bg-gray-500";
  }
};

export default CareCalendar;
