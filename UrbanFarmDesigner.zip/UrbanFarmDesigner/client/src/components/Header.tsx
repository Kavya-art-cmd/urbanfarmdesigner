import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="bg-white border-b border-neutral-200 py-4 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <svg className="text-primary h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2L11.2 3.5C11 3.8 10.8 4.1 10.7 4.4L9.8 7.1C9.4 8.3 9.8 9.6 10.8 10.3L11.4 10.7C11.8 11 12 11.4 12 11.9V13.5C12 14.1 11.8 14.7 11.4 15.2L11 15.8C10.6 16.3 10.4 16.9 10.4 17.5V22M12 2C12 2 14 6 14 7.5C14 8.9 13.3 10 12 10C10.7 10 10 8.9 10 7.5C10 6 12 2 12 2ZM20 19C20 21.2 16.4 23 12 23C7.6 23 4 21.2 4 19C4 17.8 4 17 7 17L15.6 17C19.1 17 20 17.3 20 19Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <Link href="/">
            <a className="text-xl sm:text-2xl font-bold text-neutral-800">Home Farm Designer</a>
          </Link>
        </div>
        
        <nav className="hidden md:flex space-x-6">
          <Link href="/">
            <a className="text-neutral-600 hover:text-primary font-medium transition-colors duration-200">Designs</a>
          </Link>
          <Link href="/#plants">
            <a className="text-neutral-600 hover:text-primary font-medium transition-colors duration-200">Plants</a>
          </Link>
          <Link href="/#guide">
            <a className="text-neutral-600 hover:text-primary font-medium transition-colors duration-200">Guide</a>
          </Link>
          <Link href="/#community">
            <a className="text-neutral-600 hover:text-primary font-medium transition-colors duration-200">Community</a>
          </Link>
        </nav>
        
        <div className="flex items-center space-x-4">
          <Button className="hidden md:block bg-primary hover:bg-[#388E3C]">
            Get Started
          </Button>
          
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col space-y-4 mt-8">
                <Link href="/">
                  <a className="text-lg font-medium" onClick={() => setIsOpen(false)}>Designs</a>
                </Link>
                <Link href="/#plants">
                  <a className="text-lg font-medium" onClick={() => setIsOpen(false)}>Plants</a>
                </Link>
                <Link href="/#guide">
                  <a className="text-lg font-medium" onClick={() => setIsOpen(false)}>Guide</a>
                </Link>
                <Link href="/#community">
                  <a className="text-lg font-medium" onClick={() => setIsOpen(false)}>Community</a>
                </Link>
                <Button className="w-full">Get Started</Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
