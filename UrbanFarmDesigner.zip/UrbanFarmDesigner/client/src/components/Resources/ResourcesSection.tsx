import { Card, CardContent } from "@/components/ui/card";
import { 
  Book, 
  Video, 
  Users,
  ArrowRight
} from "lucide-react";

const ResourcesSection = () => {
  const resources = [
    {
      icon: <Book className="text-primary h-6 w-6" />,
      title: "Beginner's Guide",
      description: "Essential knowledge for getting started with your first urban garden.",
      link: "#",
      linkText: "Read Guide"
    },
    {
      icon: <Video className="text-primary h-6 w-6" />,
      title: "Video Tutorials",
      description: "Step-by-step video guides for planting, care and harvesting techniques.",
      link: "#",
      linkText: "Watch Videos"
    },
    {
      icon: <Users className="text-primary h-6 w-6" />,
      title: "Community Forum",
      description: "Connect with other urban gardeners to share tips and get advice.",
      link: "#",
      linkText: "Join Community"
    }
  ];

  return (
    <section id="guide" className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-neutral-800 mb-4">Gardening Resources</h2>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Learn from our collection of guides and tips to elevate your urban gardening skills.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource, index) => (
            <Card key={index} className="bg-neutral-100 shadow-sm">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  {resource.icon}
                </div>
                <h3 className="font-bold text-lg mb-2">{resource.title}</h3>
                <p className="text-neutral-600 mb-4">{resource.description}</p>
                <a 
                  href={resource.link} 
                  className="text-primary hover:text-[#388E3C] font-medium inline-flex items-center"
                >
                  {resource.linkText} <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ResourcesSection;
