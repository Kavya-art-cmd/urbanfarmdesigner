import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { type Plant } from "@/lib/types";

interface RecommendedPlantsProps {
  designId?: number;
  sunlightExposure: string;
  preferences: string[];
}

const RecommendedPlants = ({ designId, sunlightExposure, preferences }: RecommendedPlantsProps) => {
  const { toast } = useToast();
  const [selectedPlants, setSelectedPlants] = useState<number[]>([]);

  // Fetch recommended plants
  const { data: plantsByType, isLoading, error } = useQuery({
    queryKey: ['/api/recommend-plants'],
    queryFn: async () => {
      const res = await fetch('/api/recommend-plants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ designId, sunlightExposure, preferences }),
      });
      
      if (!res.ok) {
        throw new Error('Failed to load plant recommendations');
      }
      
      return res.json();
    },
    enabled: !!sunlightExposure && preferences.length > 0,
  });

  useEffect(() => {
    if (error) {
      toast({
        title: "Error loading plants",
        description: "Could not load plant recommendations. Please try again.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  const togglePlantSelection = (plantId: number) => {
    setSelectedPlants(prev => 
      prev.includes(plantId) 
        ? prev.filter(id => id !== plantId) 
        : [...prev, plantId]
    );
  };

  if (isLoading) {
    return (
      <section className="py-12 bg-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <Skeleton className="h-8 w-64 mx-auto mb-4" />
            <Skeleton className="h-4 w-full max-w-2xl mx-auto" />
          </div>
          
          <LoadingPlantGrid />
        </div>
      </section>
    );
  }

  return (
    <section id="plants" className="py-12 bg-neutral-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-neutral-800 mb-4">Recommended Plants</h2>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Based on your space and design choice, here are the ideal plants for your urban garden.
          </p>
        </div>

        {plantsByType && Object.entries(plantsByType).map(([type, plants]) => (
          <div key={type} className="mb-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-medium text-neutral-800">
                {formatPlantType(type)} <span className="text-sm text-neutral-500 font-normal">({getPlantTypeDescription(type)})</span>
              </h3>
              <Button variant="link" className="text-primary hover:text-[#388E3C] font-medium">
                View All {formatPlantType(type)} <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5 mb-8">
              {(plants as Plant[]).map((plant) => (
                <PlantCard 
                  key={plant.id} 
                  plant={plant} 
                  isSelected={selectedPlants.includes(plant.id)}
                  onToggleSelect={() => togglePlantSelection(plant.id)}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

// Helper component for plant cards
const PlantCard = ({ 
  plant, 
  isSelected, 
  onToggleSelect 
}: { 
  plant: Plant; 
  isSelected: boolean;
  onToggleSelect: () => void;
}) => {
  return (
    <div className="plant-card bg-white rounded-xl overflow-hidden shadow-sm">
      <div className="relative">
        <img 
          src={plant.imageUrl} 
          alt={plant.name} 
          className="w-full h-40 object-cover" 
        />
        {plant.specialFeature && (
          <div className="absolute top-0 right-0 bg-green-100 text-primary text-xs font-bold px-2 py-1 rounded-bl-lg">
            {plant.specialFeature}
          </div>
        )}
      </div>
      <div className="p-4">
        <h4 className="font-bold text-lg mb-1">{plant.name}</h4>
        <p className="text-neutral-500 text-sm mb-3">{plant.description}</p>
        
        <div className="flex flex-wrap gap-2 mb-3">
          <Badge variant="outline" className="bg-neutral-100 text-neutral-700 hover:bg-neutral-200">
            {getSunlightLabel(plant.sunlight)}
          </Badge>
          <Badge variant="outline" className="bg-neutral-100 text-neutral-700 hover:bg-neutral-200">
            {getWaterNeedsLabel(plant.waterNeeds)}
          </Badge>
          <Badge variant="outline" className="bg-neutral-100 text-neutral-700 hover:bg-neutral-200">
            {plant.careLevel}
          </Badge>
        </div>
        
        <Button 
          className={`w-full ${isSelected ? 'bg-[#388E3C]' : 'bg-[#8BC34A]'} hover:bg-primary text-white font-medium py-1.5 px-4 rounded-lg h-auto text-sm`}
          onClick={onToggleSelect}
        >
          {isSelected ? 'Remove from Garden' : 'Add to My Garden'}
        </Button>
      </div>
    </div>
  );
};

// Loading skeleton for plant grid
const LoadingPlantGrid = () => (
  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5 mb-8">
    {Array(4).fill(0).map((_, index) => (
      <div key={index} className="bg-white rounded-xl overflow-hidden shadow-sm">
        <Skeleton className="w-full h-40" />
        <div className="p-4 space-y-3">
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-4 w-full" />
          <div className="flex gap-2">
            <Skeleton className="h-6 w-20" />
            <Skeleton className="h-6 w-20" />
            <Skeleton className="h-6 w-20" />
          </div>
          <Skeleton className="h-8 w-full" />
        </div>
      </div>
    ))}
  </div>
);

// Helper functions for mapping values to display labels
function formatPlantType(type: string): string {
  return type.charAt(0).toUpperCase() + type.slice(1) + 's';
}

function getPlantTypeDescription(type: string): string {
  const descriptions: Record<string, string> = {
    "herb": "Perfect for vertical gardens",
    "vegetable": "Ideal for container gardening",
    "flower": "Add color and attract pollinators",
    "fruit": "Delicious edibles for your garden"
  };
  return descriptions[type] || '';
}

function getSunlightLabel(sunlight: string): string {
  const options: Record<string, string> = {
    "full": "Full Sun",
    "partial": "Partial Sun",
    "shade": "Shade",
    "full-partial": "Full-Partial Sun"
  };
  return options[sunlight] || sunlight;
}

function getWaterNeedsLabel(water: string): string {
  const options: Record<string, string> = {
    "low": "Low Water",
    "medium": "Medium Water",
    "high": "High Water",
    "regular": "Regular Water"
  };
  return options[water] || water;
}

export default RecommendedPlants;
