import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Sun, 
  Droplets, 
  Leaf,
  ChevronRight
} from "lucide-react";
import { type GardenDesign } from "@/lib/types";

interface DesignResultsProps {
  designs: GardenDesign[];
  isLoading?: boolean;
  onSelectDesign: (design: GardenDesign) => void;
}

const DesignResults = ({ designs, isLoading = false, onSelectDesign }: DesignResultsProps) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Only show the section if we have designs
    if (designs && designs.length > 0) {
      setIsVisible(true);
    }
  }, [designs]);

  if (!isVisible && !isLoading) {
    return null;
  }

  return (
    <div id="design-results" className="py-8">
      <h3 className="text-2xl font-bold text-neutral-800 mb-6 text-center">
        {isLoading ? "Preparing Your Garden Design Options..." : "Your Garden Design Options"}
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        {isLoading ? (
          Array(3).fill(0).map((_, index) => (
            <div key={index} className="bg-white rounded-xl overflow-hidden shadow-md">
              <Skeleton className="w-full h-48" />
              <div className="p-5 space-y-4">
                <Skeleton className="h-6 w-2/3" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <div className="flex justify-between">
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-10 w-24" />
                </div>
              </div>
            </div>
          ))
        ) : (
          designs.map((design) => (
            <div key={design.id} className="garden-card bg-white rounded-xl overflow-hidden shadow-md">
              <div className="relative">
                <img 
                  src={design.imageUrl} 
                  alt={design.name} 
                  className="w-full h-48 object-cover"
                />
                <div className={`absolute top-0 right-0 ${getTagColor(design.designType)} text-white text-sm font-bold px-3 py-1 rounded-bl-lg`}>
                  {getDesignTypeLabel(design.designType)}
                </div>
              </div>
              <div className="p-5">
                <h4 className="font-bold text-lg mb-2">{design.name}</h4>
                <p className="text-neutral-600 text-sm mb-4">{design.description}</p>
                
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center space-x-2">
                    <Sun className="text-yellow-500 h-4 w-4" />
                    <span className="text-sm">{getSunlightLabel(design.sunlight)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Droplets className="text-blue-500 h-4 w-4" />
                    <span className="text-sm">{getWaterNeedsLabel(design.waterNeeds)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Leaf className="text-green-500 h-4 w-4" />
                    <span className="text-sm">{getCareLevelLabel(design.careLevel)}</span>
                  </div>
                </div>
                
                <div className="flex justify-between">
                  <Button 
                    className="bg-primary hover:bg-[#388E3C]"
                    onClick={() => onSelectDesign(design)}
                  >
                    Select Design
                  </Button>
                  <Link href={`/designs/${design.id}`}>
                    <Button variant="outline" className="text-primary border-primary hover:bg-primary hover:text-white">
                      View Details
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

// Helper functions for mapping values to display labels
function getDesignTypeLabel(type: string): string {
  const types: Record<string, string> = {
    "vertical": "Vertical Garden",
    "container": "Container Garden",
    "hybrid": "Hybrid Garden",
  };
  return types[type] || type;
}

function getSunlightLabel(sunlight: string): string {
  const options: Record<string, string> = {
    "full": "Full Sun",
    "partial": "Partial Sun",
    "shade": "Shade",
    "full-partial": "Full-Partial"
  };
  return options[sunlight] || sunlight;
}

function getWaterNeedsLabel(water: string): string {
  const options: Record<string, string> = {
    "low": "Low Water",
    "medium": "Medium Water",
    "high": "High Water"
  };
  return options[water] || water;
}

function getCareLevelLabel(care: string): string {
  const options: Record<string, string> = {
    "easy": "Easy Care",
    "moderate": "Moderate Care",
    "advanced": "Advanced Care"
  };
  return options[care] || care;
}

function getTagColor(type: string): string {
  const colors: Record<string, string> = {
    "vertical": "bg-primary",
    "container": "bg-accent",
    "hybrid": "bg-[#8BC34A]"
  };
  return colors[type] || "bg-primary";
}

export default DesignResults;
