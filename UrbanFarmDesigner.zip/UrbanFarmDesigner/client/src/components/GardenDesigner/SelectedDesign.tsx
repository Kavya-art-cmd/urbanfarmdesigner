import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  Download, 
  CheckCircle,
  Circle
} from "lucide-react";
import { type GardenDesign } from "@/lib/types";

interface SelectedDesignProps {
  design: GardenDesign | null;
}

const SelectedDesign = ({ design }: SelectedDesignProps) => {
  const [isSaving, setIsSaving] = useState(false);

  if (!design) {
    return null;
  }

  const handleSaveDesign = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      // Here you would typically save the design to the user's account
      alert("Design saved successfully!");
    }, 1000);
  };

  return (
    <Card className="bg-neutral-100 rounded-2xl">
      <CardContent className="p-6 sm:p-8">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold text-neutral-800">
            Your Selected Design: {design.name}
          </h3>
          <span className={`${getTagColor(design.designType)} text-white text-sm font-bold px-3 py-1 rounded-lg`}>
            {getDesignTypeLabel(design.designType)}
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="relative bg-white rounded-xl overflow-hidden shadow-sm">
              <img 
                src={design.imageUrl} 
                alt={`Detailed ${design.name}`} 
                className="w-full h-auto" 
              />
              
              {/* Layout overlay markers */}
              <div className="absolute top-[20%] left-[25%] bg-primary bg-opacity-80 text-white text-xs px-2 py-1 rounded">
                Herbs Zone
              </div>
              <div className="absolute top-[45%] left-[60%] bg-[#8BC34A] bg-opacity-80 text-white text-xs px-2 py-1 rounded">
                Microgreens
              </div>
              <div className="absolute top-[70%] left-[30%] bg-accent bg-opacity-80 text-white text-xs px-2 py-1 rounded">
                Compact Vegetables
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white p-5 rounded-xl shadow-sm h-full">
              <h4 className="font-bold text-lg mb-4">Design Details</h4>
              
              <div className="space-y-4">
                <div>
                  <h5 className="font-medium text-neutral-700 mb-1">Space Utilization</h5>
                  <Progress value={design.spaceEfficiency} className="h-2.5" />
                  <p className="text-sm text-neutral-600 mt-1">{design.spaceEfficiency}% space efficiency</p>
                </div>
                
                <div>
                  <h5 className="font-medium text-neutral-700 mb-1">Estimated Yield</h5>
                  <p className="text-sm text-neutral-600">
                    <span className="text-[#8BC34A] mr-1">•</span> 
                    4-6 herb varieties (continuous harvest)
                  </p>
                  <p className="text-sm text-neutral-600">
                    <span className="text-accent mr-1">•</span> 
                    2-3 small vegetable varieties (seasonal)
                  </p>
                </div>

                <div>
                  <h5 className="font-medium text-neutral-700 mb-1">Materials Needed</h5>
                  <ul className="text-sm text-neutral-600 list-disc ml-5 space-y-1">
                    {(design.materialsList as string[]).map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h5 className="font-medium text-neutral-700 mb-1">Maintenance Level</h5>
                  <div className="flex items-center">
                    <span className="text-sm text-neutral-600 mr-2">Low</span>
                    <div className="flex items-center">
                      {renderMaintenanceLevel(design.careLevel)}
                    </div>
                    <span className="text-sm text-neutral-600 ml-2">High</span>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <Button 
                  className="w-full bg-primary hover:bg-[#388E3C] font-bold"
                  onClick={handleSaveDesign}
                  disabled={isSaving}
                >
                  <Download className="mr-2 h-4 w-4" /> Save Design
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Helper functions
function getDesignTypeLabel(type: string): string {
  const types: Record<string, string> = {
    "vertical": "Vertical Garden",
    "container": "Container Garden",
    "hybrid": "Hybrid Garden",
  };
  return types[type] || type;
}

function getTagColor(type: string): string {
  const colors: Record<string, string> = {
    "vertical": "bg-primary",
    "container": "bg-accent",
    "hybrid": "bg-[#8BC34A]"
  };
  return colors[type] || "bg-primary";
}

function renderMaintenanceLevel(careLevel: string) {
  // Map care level to a numeric value for display
  const levelMap: Record<string, number> = {
    "easy": 2,
    "moderate": 3,
    "advanced": 5
  };
  
  const level = levelMap[careLevel] || 3;
  const dots = [];
  
  for (let i = 1; i <= 5; i++) {
    if (i <= level) {
      dots.push(<CheckCircle key={i} className="text-primary h-3 w-3 mr-1" />);
    } else {
      dots.push(<Circle key={i} className="text-neutral-300 h-3 w-3 mr-1" />);
    }
  }
  
  return dots;
}

export default SelectedDesign;
