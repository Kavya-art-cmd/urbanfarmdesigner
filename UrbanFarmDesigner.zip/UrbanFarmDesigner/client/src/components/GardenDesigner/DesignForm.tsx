import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, Loader2 } from "lucide-react";

const formSchema = z.object({
  spaceType: z.enum(["balcony", "terrace", "indoor"]),
  sunlightExposure: z.enum(["full", "partial", "shade"]),
  width: z.number().min(2).max(20),
  length: z.number().min(2).max(30),
  preferences: z.array(z.enum(["vegetable", "herb", "flower", "fruit"])).min(1, "Select at least one preference"),
  photoUrl: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

interface DesignFormProps {
  onDesignsGenerated: (designs: any[]) => void;
}

const DesignForm = ({ onDesignsGenerated }: DesignFormProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      spaceType: "balcony",
      sunlightExposure: "full",
      width: 6,
      length: 8,
      preferences: ["vegetable", "herb"],
      photoUrl: "",
    },
  });

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      const response = await apiRequest("POST", "/api/generate-designs", data);
      const designs = await response.json();
      
      onDesignsGenerated(designs);
      
      // Scroll to results
      setTimeout(() => {
        const resultsElement = document.getElementById("design-results");
        if (resultsElement) {
          resultsElement.scrollIntoView({ behavior: "smooth" });
        }
      }, 100);
      
      toast({
        title: "Garden designs generated!",
        description: "Check out your personalized garden designs below.",
      });
    } catch (error) {
      toast({
        title: "Error generating designs",
        description: "Please try again with different parameters.",
        variant: "destructive",
      });
      console.error("Error generating designs:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card id="design-form" className="bg-neutral-100 rounded-2xl shadow-sm">
      <CardContent className="p-6 sm:p-8">
        <h3 className="text-xl font-semibold mb-6 text-neutral-800">Space Details</h3>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <Label className="font-medium text-neutral-700">Space Type</Label>
              <RadioGroup
                defaultValue={form.getValues("spaceType")}
                onValueChange={(value) => form.setValue("spaceType", value as "balcony" | "terrace" | "indoor")}
                className="flex space-x-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="balcony" id="balcony" />
                  <Label htmlFor="balcony">Balcony</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="terrace" id="terrace" />
                  <Label htmlFor="terrace">Terrace</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="indoor" id="indoor" />
                  <Label htmlFor="indoor">Indoor</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-3">
              <Label className="font-medium text-neutral-700">Sunlight Exposure</Label>
              <RadioGroup
                defaultValue={form.getValues("sunlightExposure")}
                onValueChange={(value) => form.setValue("sunlightExposure", value as "full" | "partial" | "shade")}
                className="flex space-x-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="full" id="full" />
                  <Label htmlFor="full">Full Sun</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="partial" id="partial" />
                  <Label htmlFor="partial">Partial</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="shade" id="shade" />
                  <Label htmlFor="shade">Shade</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <Label className="font-medium text-neutral-700">Space Width (feet)</Label>
                <span className="font-bold text-primary">{form.watch("width")} ft</span>
              </div>
              <Slider
                min={2}
                max={20}
                step={1}
                defaultValue={[form.getValues("width")]}
                onValueChange={(values) => form.setValue("width", values[0])}
                className="py-4"
              />
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <Label className="font-medium text-neutral-700">Space Length (feet)</Label>
                <span className="font-bold text-primary">{form.watch("length")} ft</span>
              </div>
              <Slider
                min={2}
                max={30}
                step={1}
                defaultValue={[form.getValues("length")]}
                onValueChange={(values) => form.setValue("length", values[0])}
                className="py-4"
              />
            </div>

            <div className="md:col-span-2">
              <Label className="block font-medium text-neutral-700 mb-2">What would you like to grow?</Label>
              <div className="flex flex-wrap gap-3">
                <label className="flex items-center bg-white border border-neutral-300 rounded-full px-4 py-2 cursor-pointer hover:border-primary transition">
                  <Checkbox 
                    checked={form.watch("preferences").includes("vegetable")}
                    onCheckedChange={(checked) => {
                      const current = form.getValues("preferences");
                      if (checked) {
                        form.setValue("preferences", [...current, "vegetable"]);
                      } else {
                        form.setValue("preferences", current.filter(p => p !== "vegetable"));
                      }
                    }}
                    className="mr-2"
                  />
                  <span>Vegetables</span>
                </label>
                
                <label className="flex items-center bg-white border border-neutral-300 rounded-full px-4 py-2 cursor-pointer hover:border-primary transition">
                  <Checkbox 
                    checked={form.watch("preferences").includes("herb")}
                    onCheckedChange={(checked) => {
                      const current = form.getValues("preferences");
                      if (checked) {
                        form.setValue("preferences", [...current, "herb"]);
                      } else {
                        form.setValue("preferences", current.filter(p => p !== "herb"));
                      }
                    }}
                    className="mr-2"
                  />
                  <span>Herbs</span>
                </label>
                
                <label className="flex items-center bg-white border border-neutral-300 rounded-full px-4 py-2 cursor-pointer hover:border-primary transition">
                  <Checkbox 
                    checked={form.watch("preferences").includes("flower")}
                    onCheckedChange={(checked) => {
                      const current = form.getValues("preferences");
                      if (checked) {
                        form.setValue("preferences", [...current, "flower"]);
                      } else {
                        form.setValue("preferences", current.filter(p => p !== "flower"));
                      }
                    }}
                    className="mr-2"
                  />
                  <span>Flowers</span>
                </label>
                
                <label className="flex items-center bg-white border border-neutral-300 rounded-full px-4 py-2 cursor-pointer hover:border-primary transition">
                  <Checkbox 
                    checked={form.watch("preferences").includes("fruit")}
                    onCheckedChange={(checked) => {
                      const current = form.getValues("preferences");
                      if (checked) {
                        form.setValue("preferences", [...current, "fruit"]);
                      } else {
                        form.setValue("preferences", current.filter(p => p !== "fruit"));
                      }
                    }}
                    className="mr-2"
                  />
                  <span>Fruits</span>
                </label>
              </div>
            </div>

            <div className="md:col-span-2">
              <Label className="block font-medium text-neutral-700 mb-2">Upload a photo of your space (optional)</Label>
              <div className="border-2 border-dashed border-neutral-300 rounded-lg p-8 text-center hover:border-primary transition cursor-pointer">
                <Upload className="mx-auto h-10 w-10 text-neutral-400 mb-3" />
                <p className="text-neutral-600">Drag and drop a photo or <span className="text-primary font-medium">browse files</span></p>
                <p className="text-neutral-500 text-sm mt-2">PNG, JPG or JPEG (max. 5MB)</p>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center">
            <Button 
              type="submit" 
              className="bg-primary hover:bg-[#388E3C] font-bold py-3 px-8 h-auto" 
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                  Generating...
                </>
              ) : (
                "Generate Garden Designs"
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default DesignForm;
