import { Switch, Route } from "wouter";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import DesignDetail from "@/pages/DesignDetail";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/designs/:id" component={DesignDetail} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <TooltipProvider>
      <Router />
    </TooltipProvider>
  );
}

export default App;
