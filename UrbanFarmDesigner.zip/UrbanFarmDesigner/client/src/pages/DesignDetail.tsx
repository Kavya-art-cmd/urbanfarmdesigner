import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SelectedDesign from "@/components/GardenDesigner/SelectedDesign";
import RecommendedPlants from "@/components/Plants/RecommendedPlants";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft } from "lucide-react";
import { type GardenDesign } from "@/lib/types";

const DesignDetail = () => {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const designId = parseInt(params.id);

  // Fetch the design details
  const { data: design, isLoading, error } = useQuery<GardenDesign>({
    queryKey: [`/api/garden-designs/${designId}`],
    enabled: !isNaN(designId),
  });

  useEffect(() => {
    if (error) {
      toast({
        title: "Error loading design",
        description: "Could not load the garden design. Please try again.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  const handleBack = () => {
    setLocation("/");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Button variant="ghost" className="mb-6" onClick={handleBack}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Designs
            </Button>
            
            <Skeleton className="h-8 w-64 mb-6" />
            <Skeleton className="h-[400px] w-full mb-8 rounded-lg" />
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!design) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Design Not Found</h2>
            <p className="mb-6">The garden design you are looking for does not exist.</p>
            <Button onClick={handleBack}>Go Back to Home</Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" className="mb-6" onClick={handleBack}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Designs
          </Button>
          
          <div className="mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-neutral-800 mb-6">
              {design.name}: Detailed View
            </h2>
            
            <SelectedDesign design={design} />
          </div>
          
          <RecommendedPlants 
            designId={design.id} 
            sunlightExposure={design.sunlight}
            preferences={["vegetable", "herb"]} // Default preferences
          />
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default DesignDetail;
