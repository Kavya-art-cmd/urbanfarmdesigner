import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import DesignForm from "@/components/GardenDesigner/DesignForm";
import DesignResults from "@/components/GardenDesigner/DesignResults";
import SelectedDesign from "@/components/GardenDesigner/SelectedDesign";
import RecommendedPlants from "@/components/Plants/RecommendedPlants";
import CareCalendar from "@/components/CareCalendar/CareCalendar";
import ProgressTracker from "@/components/ProgressTracker/ProgressTracker";
import ResourcesSection from "@/components/Resources/ResourcesSection";
import { type GardenDesign } from "@/lib/types";

const Home = () => {
  const [designs, setDesigns] = useState<GardenDesign[]>([]);
  const [selectedDesign, setSelectedDesign] = useState<GardenDesign | null>(null);
  const [spaceDetails, setSpaceDetails] = useState({
    sunlightExposure: "full",
    preferences: ["vegetable", "herb"]
  });

  const handleDesignsGenerated = (newDesigns: GardenDesign[]) => {
    setDesigns(newDesigns);
    // Clear any previously selected design
    setSelectedDesign(null);
  };

  const handleSelectDesign = (design: GardenDesign) => {
    setSelectedDesign(design);
    
    // Scroll to the selected design section
    setTimeout(() => {
      const selectedDesignElement = document.getElementById("selected-design");
      if (selectedDesignElement) {
        selectedDesignElement.scrollIntoView({ behavior: "smooth" });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <Hero />
        
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-neutral-800 mb-4">Design Your Home Farm</h2>
              <p className="text-neutral-600 max-w-2xl mx-auto">
                Enter your space details below, and we'll help you create the perfect garden layout for your urban home.
              </p>
            </div>

            <DesignForm onDesignsGenerated={handleDesignsGenerated} />
            
            <DesignResults 
              designs={designs} 
              onSelectDesign={handleSelectDesign} 
            />
            
            {selectedDesign && (
              <div id="selected-design" className="mt-10">
                <SelectedDesign design={selectedDesign} />
              </div>
            )}
          </div>
        </section>

        {(designs.length > 0 || selectedDesign) && (
          <>
            <RecommendedPlants 
              designId={selectedDesign?.id} 
              sunlightExposure={spaceDetails.sunlightExposure}
              preferences={spaceDetails.preferences}
            />
            
            <CareCalendar />
            
            <ProgressTracker />
          </>
        )}
        
        <ResourcesSection />
      </main>
      
      <Footer />
    </div>
  );
};

export default Home;
