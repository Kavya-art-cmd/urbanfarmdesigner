import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Garden spaces schema
export const gardenSpaces = pgTable("garden_spaces", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  spaceType: text("space_type").notNull(), // balcony, terrace, indoor
  width: integer("width").notNull(), // in feet
  length: integer("length").notNull(), // in feet
  sunlightExposure: text("sunlight_exposure").notNull(), // full, partial, shade
  preferences: jsonb("preferences").notNull(), // what they want to grow
  photoUrl: text("photo_url"), // optional photo
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertGardenSpaceSchema = createInsertSchema(gardenSpaces).omit({
  id: true,
  createdAt: true,
});

// Garden designs schema
export const gardenDesigns = pgTable("garden_designs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  designType: text("design_type").notNull(), // vertical, container, hybrid
  imageUrl: text("image_url").notNull(),
  sunlight: text("sunlight").notNull(), // full, partial, shade
  waterNeeds: text("water_needs").notNull(), // low, medium, high
  careLevel: text("care_level").notNull(), // easy, moderate, advanced
  spaceEfficiency: integer("space_efficiency").notNull(), // percentage
  materialsList: jsonb("materials_list").notNull(),
});

export const insertGardenDesignSchema = createInsertSchema(gardenDesigns).omit({
  id: true,
});

// Plants schema
export const plants = pgTable("plants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // herb, vegetable, flower, fruit
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  sunlight: text("sunlight").notNull(), // full, partial, shade
  waterNeeds: text("water_needs").notNull(), // low, medium, high
  careLevel: text("care_level").notNull(), // beginner, intermediate, advanced
  specialFeature: text("special_feature"), // e.g., "Fast Growing", "Drought Tolerant"
  harvestTime: text("harvest_time"), // time to harvest if applicable
});

export const insertPlantSchema = createInsertSchema(plants).omit({
  id: true,
});

// User garden selections schema
export const userGardens = pgTable("user_gardens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  gardenSpaceId: integer("garden_space_id").references(() => gardenSpaces.id),
  designId: integer("design_id").references(() => gardenDesigns.id),
  selectedPlants: jsonb("selected_plants").notNull(), // array of plant IDs
  progress: integer("progress").notNull().default(0), // percentage completion
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserGardenSchema = createInsertSchema(userGardens).omit({
  id: true,
  createdAt: true,
});

// Care tasks schema
export const careTasks = pgTable("care_tasks", {
  id: serial("id").primaryKey(),
  userGardenId: integer("user_garden_id").references(() => userGardens.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  taskType: text("task_type").notNull(), // water, prune, harvest, fertilize
  dueDate: timestamp("due_date").notNull(),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCareTaskSchema = createInsertSchema(careTasks).omit({
  id: true,
  createdAt: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type GardenSpace = typeof gardenSpaces.$inferSelect;
export type InsertGardenSpace = z.infer<typeof insertGardenSpaceSchema>;

export type GardenDesign = typeof gardenDesigns.$inferSelect;
export type InsertGardenDesign = z.infer<typeof insertGardenDesignSchema>;

export type Plant = typeof plants.$inferSelect;
export type InsertPlant = z.infer<typeof insertPlantSchema>;

export type UserGarden = typeof userGardens.$inferSelect;
export type InsertUserGarden = z.infer<typeof insertUserGardenSchema>;

export type CareTask = typeof careTasks.$inferSelect;
export type InsertCareTask = z.infer<typeof insertCareTaskSchema>;
